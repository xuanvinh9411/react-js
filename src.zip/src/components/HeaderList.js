import React from 'react';

class HearderList extends React.Component {
  render() {
  return (
    <thead>
    <tr>
        <th className="text-center">STT</th>
        <th className="text-center">Tên</th>
        <th className="text-center">Trạng Thái</th>
        <th className="text-center">Hành Động</th>
    </tr>
</thead>

  );
}
}

export default HearderList;
