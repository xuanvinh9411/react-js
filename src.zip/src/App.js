import React from 'react';
import './App.css';
import TaskForm from './components/TaskForm';
import SearchForm from './components/SearchForm';
import ListForm from './components/ListForm';

class App extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            tasks: [

            ],
            tasksEditing: [

            ],

            isDisplayForm: false
        }
    }
    componentWillMount() {
        if (localStorage && localStorage.getItem('tasks')) {
            var tasks = JSON.parse(localStorage.getItem('tasks'));
            this.setState({
                tasks: tasks
            });
        }
    }
    onGenerateData = () => {
        var tasks = [
            {
                id: this.generateID(),
                name: 'Học lạp trình1',
                status: true
            },

            {
                id: this.generateID(),
                name: 'Học lạp trình2',
                status: false
            },
            {
                id: this.generateID(),
                name: 'Học lạp trình3',
                status: false
            }
        ];
        this.setState({
            tasks: tasks
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    addForm = () => {
        if (this.state.isDisplayForm && this.state.tasksEditing !== null) {
            this.setState({
                isDisplayForm: true,
                tasksEditing: null
            })
        }
        else {
            this.setState({
                isDisplayForm: !this.state.isDisplayForm,
                tasksEditing: null
            })
        }

    }

    closeForm = () => {
        this.setState({
            isDisplayForm: !this.state.isDisplayForm
        })
    }

    showForm = () => {
        this.setState({
            isDisplayForm: true
        })
    }

    s4() {
        return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
    }
    generateID() {
        return this.s4() + this.s4() + '_' + this.s4() + '_'
    }
    onSubmit = (data) => {
        var tasks = this.state.tasks;
        if (data.id == null) {
            data.id = this.generateID();
            tasks.push(data);
        }
        else {
            var index = this.findIndex(data.id);
            tasks[index] = data;
        }
        this.setState(
            {
                tasks: tasks,
                tasksEditing: null
            }
        )
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }
    onUpdateStatus = (id) => {
        var { tasks } = this.state;
        var index = this.findIndex(id);
        if (index !== -1) {
            tasks[index].status = !tasks[index].status
            this.setState({
                tasks: tasks
            })
        }
        localStorage.setItem('tasks', JSON.stringify(tasks));

    }
    findIndex = (id) => {
        var { tasks } = this.state;
        var result = -1;
        tasks.forEach((task, index) => {
            if (task.id === id) {
                result = index;
            }
        });
        return result;
    }
    onDelete = (id) => {
        var { tasks } = this.state;
        var index = this.findIndex(id);
        if (index !== -1) {
            tasks.splice(index, 1);
            this.setState({
                tasks: tasks
            })
        }
        localStorage.setItem('tasks', JSON.stringify(tasks));
        this.closeForm()
    }

    onUpdate = (id) => {
        var { tasks } = this.state
        var index = this.findIndex(id);
        var tasksEditing = tasks[index]
        this.setState({
            tasksEditing: tasksEditing
        })
        this.showForm();
    }

    onFilter = (filterName, filterStatus) => {
    }

    render() {
        var { tasks, isDisplayForm, tasksEditing } = this.state;
        var elmTaskForm = isDisplayForm
            ? <TaskForm
                onSubmit={this.onSubmit}
                closeForm={this.closeForm}
                task={tasksEditing}
            />
            : '';
        return (
            <div className="container">
                <div className="text-center">
                    <h1>Quản Lý Công Việc</h1>
                    <hr />
                </div>
                <div className="row">
                    <div className={isDisplayForm ? 'col-xs-4 col-sm-4 col-md-4 col-lg-4' : ''}>
                        {elmTaskForm}
                    </div>
                    <div className={isDisplayForm ? 'col-xs-8 col-sm-8 col-md-8 col-lg-8' : 'col-xs-12 col-sm-12 col-md-12 col-lg-12'}>
                        <button
                            type="button"
                            className="btn btn-primary"
                            onClick={this.addForm}
                        >
                            <span className="fa fa-plus mr-5"></span>Thêm Công Việc
              </button>
                        <div className="row mt-15">
                            <SearchForm></SearchForm>
                        </div>
                        <div className="row mt-15">
                            <ListForm
                                tasks={tasks}
                                onUpdateStatus={this.onUpdateStatus}
                                onDelete={this.onDelete}
                                onUpdate={this.onUpdate}
                                onFilter={this.onFilter}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default App;
